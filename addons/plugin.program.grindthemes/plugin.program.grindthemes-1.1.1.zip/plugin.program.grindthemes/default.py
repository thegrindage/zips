################################################################################
#(_)                                                                           #
# |___________________________________________                                 #
# |`-._`-._         :|    |:         _.-'_.-'|                                 #
# |`-._`-._`-._     :|    |:     _.-'_.-'_.-'|                                 #
# |    `-._`-._`-._ :|    |: _.-'_.-'_.-'    |                                 #
# | _ _ _ _`-._`-._`:|    |:`_.-'_.-' _ _ _ _|                                 #
# |------------------      ------------------|                                 #
# |                                          |                                 #
# |__________________      __________________|                                 #
# |- - - - -_.--_.--:|    |:--._--._- - - - -|                                 #
# |     _.-'_.-'_.-':|    |:`-._`-._`-._     |                                 #
# | _.-'_.-'_.-'    :|    |:    `-._`-._`-._ |                                 #
# |'_.-'_.-'        :|    |:        `-._`-._`|                                 #
# |------------------------------------------|                                 #
# |                                                                            #
# |    GRIND      Add-on                                                         #
# |    Copyright (C) 2017                                                      #
# |                                                                            #
# |    This program is free software: you can redistribute it and/or modify    #
# |    it under the terms of the GNU General Public License as published by    #
# |    the Free Software Foundation, either version 3 of the License, or       #
# |    (at your option) any later version.                                     #
# |                                                                            #
# |    This program is distributed in the hope that it will be useful,         #
# |    but WITHOUT ANY WARRANTY; without even the implied warranty of          #
# |    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
# |    GNU General Public License for more details.                            #
# |                                                                            #
################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import time




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
dialog       =  xbmcgui.Dialog()
base = 'https://pastebin.com/raw/0QAG462Y'

def INDEX():
	link = OPEN_URL(base).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
	for name, url, icon, fanart, description in match:
		addDir(name,url,2,icon,fanart,description)

def installer(name,url,description):
	choice = xbmcgui.Dialog().yesno('Grind Images', 'WatupWatup...This will download new Backgrounds', 'This will also clear thumbnails', 'But keep calm, they will repopulate after restart.', nolabel='Cancel',yeslabel='Proceed')
	if choice == 0:
		return
	if choice == 1:
		path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
		dp = xbmcgui.DialogProgress()
		dp.create("Grind Images","Installing Super Powers to your device",'', 'Grab a drink, this may take a minute')
		lib=os.path.join(path,'images.zip')
		try:
			images = xbmc.translatePath(os.path.join('special://home','images'))
			Destroy_Path(images)
			if not os.path.exists(images): os.makedirs(images)
		except:
			pass
		download(url, lib, dp)
		time.sleep(2)
		dp.update(0,"", "Extracting Images ")
		print '======================================='
		print images
		print '======================================='
		all(lib,images,dp)
		dialog = xbmcgui.Dialog()
		dialog.ok("Grind Images", "To save changes shut this lil booger down! Hurry, Press OK to force close your Media Center, before it catches FIRE")
		thumbs = xbmc.translatePath(os.path.join('special://home/userdata','Thumbnails'))
		Destroy_Path(thumbs)
		killxbmc()

   
def OPEN_URL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def Destroy_Path(path):
    shutil.rmtree(path, ignore_errors=True)
	
def killxbmc():
	os._exit(1)


##################DOWNLOAD############################
def download(url, dest, dp = None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create("Grind Images","BOOOOYAH...Downloading Super Powers....",' ', ' ')
    dp.update(0)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url, dp):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        raise Exception("Canceled")
        dp.close()


#################EXTRACT####################################
import zipfile

def all(_in, _out, dp=None):
    if dp:
        return allWithProgress(_in, _out, dp)

    return allNoProgress(_in, _out)
        

def allNoProgress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        print str(e)
        return False

    return True


def allWithProgress(_in, _out, dp):

    zin = zipfile.ZipFile(_in,  'r')

    nFiles = float(len(zin.infolist()))
    count  = 0

    try:
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            zin.extract(item, _out)
    except Exception, e:
        print str(e)
        return False

    return True
###################################################


def addDir(name,url,mode,icon,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&icon="+urllib.quote_plus(icon)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icon)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)



        
if mode==None or url==None or len(url)<1:
        INDEX()
		
elif mode==2:installer(name,url,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
